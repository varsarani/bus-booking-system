<?php
include "top.php";
include "banner.php";
include"successcontent.php";
include "footer.php";
?>