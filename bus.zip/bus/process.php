<?php
if(isset($_POST["book"]))
{
	include "db.php";
	$first_name=$_POST["first_name"];
	$last_name=$_POST["last_name"];
	$email=$_POST["email"];
	$dob=$_POST["dob"];
	$gender=$_POST["gender"];
	$address=$_POST["address"];
	$city=$_POST["city"];
	$mobile=$_POST["bus_no"];
	$mobile=$_POST["pick_up"];
	$mobile=$_POST["destination"];
	$mobile=$_POST["mobile"];
	
	$sql="insert into users values('".$first_name."','".$last_name."','".$email."','".$dob."','".$gender."',
		'".$address."','".$city."','".$bus_no."','".$pick_up."','".$destination."','".$mobile."')";
	if(mysqli_query($con,$sql))
	{
		header("location:success.php");
	}
}
?>
<?php include "header.php";
?>





